import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Color(0xFF0A0F1A),
        primaryColor: Color(0xFFD40000),
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();

  void login() {
    if (user.text == "admin" && pass.text == "1234") {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomePage()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login gagal. Pakai admin/1234')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Image.asset('assets/drl_logo.png', height: 100),
            SizedBox(height: 20),
            Text('DRL TOOLS', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFFD40000))),
            SizedBox(height: 30),
            TextField(controller: user, decoration: InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
            SizedBox(height: 15),
            TextField(controller: pass, obscureText: true, decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
            SizedBox(height: 20),
            ElevatedButton(onPressed: login, child: Text('Login'), style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFD40000), minimumSize: Size(double.infinity, 50))),
          ]),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = [SensPage(), DpiPage(), RedeemPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('DRL TOOLS'), backgroundColor: Color(0xFF0A0F1A)),
      body: pages[index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (i) => setState(() => index = i),
        backgroundColor: Color(0xFF0A0F1A),
        selectedItemColor: Color(0xFFD40000),
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.gps_fixed), label: 'Sens'),
          BottomNavigationBarItem(icon: Icon(Icons.calculate), label: 'DPI'),
          BottomNavigationBarItem(icon: Icon(Icons.redeem), label: 'Redeem'),
        ],
      ),
    );
  }
}

class SensPage extends StatelessWidget {
  final list = [
    {'name': 'Dyland Pros', 'sens': '100, 95, 85, 75, 70'},
    {'name': 'BTR Ryzen', 'sens': '100, 100, 90, 80, 60'},
  ];
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(16),
      children: list.map((e) => Card(
        child: ListTile(
          title: Text(e['name']!),
          subtitle: Text(e['sens']!),
          trailing: IconButton(icon: Icon(Icons.copy), onPressed: () {
            Clipboard.setData(ClipboardData(text: e['sens']!));
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dicopy!')));
          }),
        ),
      )).toList(),
    );
  }
}

class DpiPage extends StatefulWidget {
  @override
  _DpiPageState createState() => _DpiPageState();
}

class _DpiPageState extends State<DpiPage> {
  TextEditingController dpi = TextEditingController();
  String hasil = '-';
  void hitung() {
    double d = double.tryParse(dpi.text)?? 0;
    if (d > 0) setState(() => hasil = (400 / d * 100).toStringAsFixed(1));
  }
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20),
      child: Column(children: [
        TextField(controller: dpi, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Masukin DPI')),
        SizedBox(height: 15),
        ElevatedButton(onPressed: hitung, child: Text('Hitung')),
        SizedBox(height: 20),
        Text('Rekomendasi Sens: $hasil', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class RedeemPage extends StatelessWidget {
  final codes = ['FF10GCGXSTSB', 'FFPLUED93XRT', 'FFMC5GZ4KMTS'];
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(16),
      children: codes.map((c) => Card(
        child: ListTile(
          title: Text(c),
          trailing: IconButton(icon: Icon(Icons.copy), onPressed: () {
            Clipboard.setData(ClipboardData(text: c));
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dicopy!')));
          }),
        ),
      )).toList(),
    );
  }
}